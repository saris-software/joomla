<?php 
defined('_JEXEC') or die('Restricted access');

function FlatViewHelperHeader($view){
	return $view->_header16();
}
