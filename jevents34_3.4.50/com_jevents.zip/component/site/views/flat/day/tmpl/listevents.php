<?php 
defined('_JEXEC') or die('Restricted access');

include(JEV_VIEWS."/default/day/tmpl/".basename(__FILE__));
