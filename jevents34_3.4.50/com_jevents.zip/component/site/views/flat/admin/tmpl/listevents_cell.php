<?php
/**
 * JEvents Component for Joomla! 3.x
 *
 * @version     $Id: listevents_cell.php 941 2010-05-20 13:21:57Z geraintedwards $
 * @package     JEvents
 * @copyright   Copyright (C) 2008-2019 GWE Systems Ltd
 * @license     GNU/GPLv2, see http://www.gnu.org/licenses/gpl-2.0.html
 * @link        http://www.jevents.net
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

include_once(JEV_VIEWS."/".$this->jevlayout."/month/tmpl/calendar_cell.php");
